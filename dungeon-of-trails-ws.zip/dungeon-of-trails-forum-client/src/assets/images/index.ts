export { default as UserJpg } from './User.jpg';
export { default as UserPng } from './user/user.png';
export { default as Notification1 } from './notification/1.jpg';
export { default as Notification2 } from './notification/2.jpg';
