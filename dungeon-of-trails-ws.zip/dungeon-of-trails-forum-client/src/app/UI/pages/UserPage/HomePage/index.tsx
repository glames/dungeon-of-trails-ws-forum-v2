import React, { useRef, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@apollo/client';
import './Demo.css';

import { useGetUserProfileQuery } from '~/app/api-interaction/GraphQL/schema';
import { getUserId } from '~/app/utils/local-storage';
import styles from './userPage.module.scss';
import { UserPostTab } from '../UserPostPage/userpost';
import { RecentCommentTab } from '../UserPostPage/recentcomment';
import { Button, Modal, ModalBody, ModalHeader } from 'reactstrap';
import { Cropper, ReactCropperElement } from 'react-cropper';
import ImageUploader from '~/app/UI/components/ImageUploader/ImageUploader';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenToSquare, faTrashAlt } from '@fortawesome/free-solid-svg-icons';

const defaultSrc =
  'https://raw.githubusercontent.com/roadmanfong/react-cropper/master/example/img/child.jpg';

const UserPage = () => {
  const { userId } = useParams();
  const [activeTab, setActiveTab] = useState('post');
  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };
  const [showOptions, setShowOptions] = useState(false);

  const [croppedImage, setCroppedImage] = useState<string | null>(null);

  const setImageAfterCrop = (image: string) => {
    setCroppedImage(image);
    SetIsOpenUploadAvaterModal(false);
  };

  const [isOpenUploadAvaterModal, SetIsOpenUploadAvaterModal] =
    useState<boolean>(false);

  // Gọi query để lấy thông tin người dùng
  const { loading, error, data } = useGetUserProfileQuery({
    variables: { userId },
  });

  const [image, setImage] = useState(defaultSrc);
  const [cropData, setCropData] = useState('#');
  const cropperRef = useRef<ReactCropperElement>(null);
  const onChange = (e: any) => {
    e.preventDefault();
    let files;
    if (e.dataTransfer) {
      files = e.dataTransfer.files;
    } else if (e.target) {
      files = e.target.files;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setImage(reader.result as any);
    };
    reader.readAsDataURL(files[0]);
  };

  const getCropData = () => {
    if (typeof cropperRef.current?.cropper !== 'undefined') {
      setCropData(cropperRef.current?.cropper.getCroppedCanvas().toDataURL());
    }
  };

  if (loading) {
    return <p>Loading...</p>;
  }

  if (error) {
    return <p>Error: {error.message}</p>;
  }

  const user = data?.GetUserProfile;

  return (
    <div className={styles.profile_page_cont}>
      <div className={styles.profile_upper}>
        <div className={styles.profile_avt}>
          <img src="/assets/images/avtar/default-avatar.png" alt="" />
          <img
            src="/assets/images/change_avt_icon.png"
            className={styles.upload_btn}
          />
        </div>
        <div>
          <h1 className={styles.profile_name}>
            <b>{user?.name}</b>
          </h1>
          <p className={styles.profile_des}>{user?.description}</p>
          {user?.gender === 1 ? (
            <div>Gender: Male</div>
          ) : (
            <div>Gender: Female</div>
          )}
        </div>
        <div className={styles.profile_setting_cont}>
          <img
            onClick={() => setShowOptions(!showOptions)}
            src="/assets/images/profile_setting_icon.png"
            alt=""
          />
          {showOptions && (
            <ul className={styles.OptionsList}>
              <li onClick={() => setShowOptions(!showOptions)}>
                <FontAwesomeIcon icon={faPenToSquare} /> &nbsp;Edit
              </li>
              {/* <li onClick={() => setShowDeleteModal(true)}>
                <FontAwesomeIcon icon={faTrashAlt} />
                &nbsp; Delete
              </li> */}
            </ul>
          )}
        </div>
      </div>
      <div className={styles.PostList}>
        <div className={styles.tabs}>
          <div
            className={`tab ${activeTab === 'post' ? 'active' : ''}`}
            onClick={() => handleTabChange('post')}
          >
            Recent Posts
          </div>
          <div
            className={`tab ${activeTab === 'cmt' ? 'active' : ''}`}
            onClick={() => handleTabChange('cmt')}
          >
            Recent Comments
          </div>
        </div>
        <div className="tab-content">
          {activeTab === 'post' && (
            <UserPostTab hotPosts={data?.GetUserProfile?.posts} />
          )}
          {activeTab === 'cmt' && (
            <RecentCommentTab hotPosts={data?.GetUserProfile?.comments} />
          )}
        </div>
      </div>
      {/* {userId === getUserId() && <button>Edit Profile</button>} */}
      <Modal isOpen={isOpenUploadAvaterModal} size="md">
        <ModalHeader toggle={() => SetIsOpenUploadAvaterModal(false)}>
          Đổi mật khẩu
        </ModalHeader>
        <ModalBody>
          <ImageUploader onCrop={setImageAfterCrop} />
          <div className="cropImage">
            {croppedImage && <img src={croppedImage} alt="Cropped Image" />}
          </div>
        </ModalBody>
      </Modal>
      <Button
        onClick={() => SetIsOpenUploadAvaterModal(!isOpenUploadAvaterModal)}
      ></Button>
    </div>
  );
};

export default UserPage;
